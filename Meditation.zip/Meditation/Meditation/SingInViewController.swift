//
//  ViewController.swift
//  Meditation
//
//  Created by user on 13.09.2022.
//

import UIKit
import Alamofire
import SwiftyJSON

class SingInViewController: UIViewController {

    @IBOutlet weak var inputLogin: UITextField!
    @IBOutlet weak var inputPassword: UITextField!
    
    @IBAction func signInAction(_ sender: UIButton) {
        
    }

}

// страница 57
